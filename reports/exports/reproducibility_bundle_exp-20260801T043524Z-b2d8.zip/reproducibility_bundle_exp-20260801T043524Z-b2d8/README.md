# IGNIS Research Reproducibility Bundle

**Experiment ID**: `exp-20260801T043524Z-b2d8`  
**Overall Verdict**: `PASS`  
**Git Commit**: `2b503f8`  
**Trial Count**: `5`  
**Execution Duration**: `3.488 seconds`  

---

## 1. System & Environment Requirements
- **Python Version**: 3.12.2
- **Operating System**: Windows 11
- **Docker Version**: Docker version 29.6.1, build 8900f1d
- **Required Container Images**:
  - `python:3.11-slim` (fog-node, edge-sim)
  - `eclipse-mosquitto:2` (mqtt-broker)
  - `influxdb:2.7` (influxdb time-series)

---

## 2. How to Reproduce Results
1. Install Python dependencies: `pip install -r environment/requirements.txt`
2. Start background container services: `docker compose up -d`
3. Execute deterministic scenario replay:
   ```bash
   python -m src.run_experiment --trials 5 --seed 4321
   ```
4. Verify generated outputs against `data/metrics.json` and `report/report.html`.

---

## 3. Core Artifact SHA256 Checksums
| File | SHA256 Hash |
|---|---|
| `data/metrics.json` | `ca9945ae4040ece493858af84170cdb2ca8ea161d94389d989e4a3d8b973c215` |
| `data/raw_results.json` | `29156df1dd937224965a9245859c467b7a7dcf56a174d59564b88d28582b8eb4` |
| `data/experiment_manifest.json` | `6a47fa2f0491e4fa727e4af22c63fc7e609ae0ac608d8e0c5a14dc468f39bd7f` |
| `report/report.html` | `f1aa361b65429aad494565867547c8db2662953cae5d77ae9b3c3ab27816069a` |
| `report/project_results_report.md` | `e8399b556edf7e8893a8d259b8fc67068c7d73715dd0dc162473c21ff7ff837b` |
